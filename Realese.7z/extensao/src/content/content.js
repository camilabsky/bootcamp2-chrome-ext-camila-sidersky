
console.log('Script de conteúdo do Murloc carregado!');
